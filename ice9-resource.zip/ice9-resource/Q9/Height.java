public class Height {
    int height = 0;
}
