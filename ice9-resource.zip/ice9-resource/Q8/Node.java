public class Node {

    // TODO: modify this code to make it a double linked list node

    private int value;   // this stores the value
    private Node next; // this stores the reference to the next node
    private Node previous; // this stores the reference to the previous node

    public Node(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public Node getNext() {
        return next;
    }

    public Node getPrevious() {
        return previous;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public void setNext(Node next) {
        this.next = next;
    }

    public void setPrevious(Node previous) {
        this.previous = previous;
    }
}